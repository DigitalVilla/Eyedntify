import React from 'react'

const Error404 = () => {
  return (
    <div>
      error 404
    </div>
  )
}

export default Error404
